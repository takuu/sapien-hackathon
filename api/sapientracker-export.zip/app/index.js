
import document from "document";
import { HeartRateSensor } from "heart-rate";
import { today } from 'user-activity';

let hrmData = document.getElementById("hrm-data");
let stepsData = document.getElementById("steps-data");

let hrm = new HeartRateSensor();

hrm.start();

function refreshData() {
  let data = {

    hrm: {
      heartRate: hrm.heartRate ? hrm.heartRate : 0
    }
  };

  hrmData.text = JSON.stringify(data.hrm.heartRate);
  stepsData.text = today.adjusted.steps;
}

refreshData();
setInterval(refreshData, 1000);
